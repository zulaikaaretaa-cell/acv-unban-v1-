package com.acv.unban;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText phoneInput = findViewById(R.id.phoneInput);
        TextView statusText = findViewById(R.id.statusText);
        Button checkButton = findViewById(R.id.checkButton);
        Button appealButton = findViewById(R.id.appealButton);

        checkButton.setOnClickListener(v -> {
            String number = phoneInput.getText().toString().trim().replaceAll("[^0-9]", "");
            if (number.length() < 8 || number.length() > 15) {
                phoneInput.setError("Masukkan nomor 8–15 digit dengan kode negara");
                return;
            }
            statusText.setText("Format nomor valid: +" + number +
                "\nStatus blokir tidak dapat diperiksa otomatis oleh aplikasi ini. Silakan ajukan peninjauan melalui WhatsApp resmi.");
            Toast.makeText(this, "Format nomor berhasil divalidasi", Toast.LENGTH_SHORT).show();
        });

        appealButton.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.whatsapp.com/contact/"));
            startActivity(intent);
        });
    }
}
