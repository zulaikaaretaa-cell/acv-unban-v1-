# ACV UNBAN V1

Aplikasi Android native sederhana bertema Cyber Blue untuk membantu pengguna memvalidasi format nomor dan menuju pusat bantuan resmi WhatsApp.

## Fitur
- Validasi format nomor internasional (8–15 digit).
- Tombol membuka pusat bantuan resmi WhatsApp.
- Panduan pengajuan peninjauan.
- Peringatan agar pengguna tidak membagikan OTP/PIN.

## Batasan penting
Aplikasi ini **tidak** dapat mengecek status blokir dari server WhatsApp, menghapus blokir, melewati sistem keamanan, atau menjamin banding diterima. Hanya WhatsApp yang dapat meninjau dan memutuskan status akun.

## Cara membuat APK
1. Ekstrak ZIP ini.
2. Buka folder `ACV_UNBAN_V1` melalui Android Studio.
3. Tunggu Gradle Sync selesai. Gunakan JDK 17 dan Android SDK 35.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug akan tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.acv.unban`
Minimum Android: Android 6.0 (API 23)
